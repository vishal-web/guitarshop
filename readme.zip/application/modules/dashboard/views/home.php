<h1>Welcome to the admin pannel</h1>
<p>
<?= anchor('web/logout','Logout') ?>
</p>