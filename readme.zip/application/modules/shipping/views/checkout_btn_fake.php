<div class="" style="text-align: right;">
	<a href="<?= base_url().'cart/go_to_checkout'?>">
		<button type="submit" name="submit" value="Submit" class="btn btn-warning">
		<span class="glyphicon glyphicon-shopping-cart"></span> Go to Checskout
		</button>
	</a>
</div>