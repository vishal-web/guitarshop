<?php
class Templates extends MX_Controller 
{

    function __construct() {
        parent::__construct();
    }

    function login($data)
    {
        if (!isset($data['view_module'])) {
            $data['view_module'] = $this->uri->segment(1);
        }
        $this->load->view('login_page',$data);
    }

    function test() 
    {
        $data = "";
        $this->public_template($data);
    }

    function _draw_breadcrumbs($data)
    {
        // NOTE: for this to work data must contains the  
        // template, current_page_title, breadcrumbs_array
        $this->load->view('breadcrumbs_public_template',$data);
    }

    function public_template($data) 
    {
        if (!isset($data['view_module'])) {
            $data['view_module'] = $this->uri->segment(1);
        }

        $this->load->module('site_security');
        $data['customer_id'] = $this->site_security->_get_user_id();
        $this->load->view('public_template',$data);
    }

    function public_jqm($data) 
    {
        if (!isset($data['view_module'])) {
            $data['view_module'] = $this->uri->segment(1);
        }
        $this->load->view('public_jqm',$data);
    }

    function admin($data) 
    {   
        if (!isset($data['view_module'])) {
            $data['view_module'] = $this->uri->segment(1);
        }
        $this->load->view('admin',$data);
    }
}