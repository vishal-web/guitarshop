<?php
Class Firstly extends MX_Controller {

	function __custruct() {
		parent:: __custruct();
	}

	function check() {
		echo "Hello ";
	}
}
?>