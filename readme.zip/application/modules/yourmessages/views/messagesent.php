<h1><?= $headline?></h1>
<p>Your Message Has Been Sent Successfully Sent</p>
<p>Thank you</p>