<?php
class Site_settings extends MX_Controller 
{

function __construct() {
parent::__construct();
}

function _get_currency_symbol() {
	$symbol = "&pound;";
	return $symbol;
}

function _get_item_segments()
{		
	// return the segements for items pages;
    $segments = "musical/instrument/";
    return $segments;
}

function _get_items_segments()
{	
	// return the segements for category pages;
    $segments = 'music/instruments/';
    return $segments;
}


function _get_page_not_found_msg()
{
	$msg = "<h1>Hi Man What you are Doing Here this Place Does Not Belong to You</h1>";
	$msg .="<h3>Go  Back and Check Out Some Cool Things ...</h3>";
	return $msg;
}

}