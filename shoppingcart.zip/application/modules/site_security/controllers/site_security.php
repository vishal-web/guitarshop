<?php
class Site_security extends MX_Controller 
{

function __construct() {
    parent::__construct();
}

function generate_random_string($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
function _hash_string($str) 
{
	$hashed_string = password_hash($str, PASSWORD_BCRYPT, ['cost'=>'12']);
	return $hashed_string;
}	

function _verify_hash($plan_text, $hashed_string)
{
	$result= password_verify($plan_text, $hashed_string);
	return $result;
}

function _make_sure_is_admin() 
{
    $is_admin = TRUE;
    if ($is_admin != TRUE) {
        redirect('Site_security/not_allowed');
    }
}

function not_allowed() 
{
    echo "You are not allowed to be here";
}

}