<div class="" style="border-radius: 7px; background-color: #ddd; margin-top: 20px; padding: 6px;">
	<table class="table">
		<tr>
			<td colspan="2">Item ID: <?= $item_id?></td>
		</tr>
		<?php
			if ($num_colors>0) {?>
		<tr>
			<td>Color:</td>
			<td>
				<?php
					$attributes = array('class'=>'form-control input-sm');
					echo form_dropdown('submitted_color',$color_options,$submitted_color,$attributes);
				?>
			</td>
		</tr>
		<?php } ?>
		<?php
			if ($num_sizes>0) {?>
		<tr>
			<td>Size:</td>
			<td>
				<?php
					$attributes = array('class'=>'form-control input-sm');
					echo form_dropdown('submitted_size',$size_options,$submitted_size,$attributes);
				?>
			</td>
		</tr>
		<?php } ?>
		
		<tr>
			<td>Qty:</td>
			<td>
				<div class="">
					<input type="text" name="quantity" class="form-control input-sm" value="" placeholder="Enter Quantity">
				</div>
			</td>
		</tr>
		<tr>
			<td colspan="2" style="text-align: center">
				<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-shopping-cart"></span> Add to Basket</button>
			</td>
			<td></td>
		</tr>
	</table>
</div>