<?php
class Cart extends MX_Controller 
{

function __construct() {
parent::__construct();
}

function _draw_add_to_cart($item_id)
{   
    $submitted_color = $this->input->post('submitted_color',TRUE);
    if ($submitted_color == "") {
        $color_options[''] = "Select Color";
    }

    $this->load->module('store_item_colors');
    $query = $this->store_item_colors->get_where_custom('item_id',$item_id);
    $data['num_colors'] = $query->num_rows();
    foreach ($query->result() as $key => $value) {
        $color_options[$value->id] = $value->color;
    }

    $data['submitted_color'] = $submitted_color;    

    $submitted_size = $this->input->post('submitted_size',TRUE);
    if ($submitted_size == "") {
        $size_options[''] = "Select Size";
    }

    $this->load->module('store_item_sizes');
    $query = $this->store_item_sizes->get_where_custom('item_id',$item_id);
    $data['num_sizes'] = $query->num_rows();
    foreach ($query->result() as $key => $value) {
        $size_options[$value->id] = $value->size;
    }

    $data['submitted_size'] = $submitted_size;
    $data['size_options'] = $size_options;
    $data['color_options'] = $color_options;
    $data['item_id'] =$item_id;
    $this->load->view('add_to_cart',$data);
}

}